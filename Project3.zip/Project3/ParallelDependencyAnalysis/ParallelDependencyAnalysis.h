#ifndef PARALLELDEPENDENCYANALYSIS_H
#define PARALLELDEPENDENCYANALYSIS_H
///////////////////////////////////////////////////////////////////////
// ParallelDependencyAnalysis.h -evaluates the dependency graph for   //
// all the packages in a specified file collection                   //
// and dependency analysis                                           //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
Evaluates the dependency graph for all the packages in a specified file collection.
For each file the analyses run asynchronously, using the facilities of the Task class. 
It implements this in two passes over the file collection. 
In the first pass it, asynchronously, finds all the types defined in the collection using services of the TypeAnalysis package. 
In the second pass it, asynchronously,finds all the dependencies between files using the DependencyAnalysis package.

Public Interface:
=================
pass1()                              //Pass1 asynchronously, finds all the types defined in the collection using services of the TypeAnalysis package
pass2()                              //asynchronously,finds all the dependencies between files using the DependencyAnalysis package
doMerge()							 //Merges the partial symbol tables into one single table
doPrint()                            // Prints the data dependency

Build Process:
==============
Required files
-  - Parser.h, Parser.cpp, TypeTable.h, TypeTable.cpp, TypeAnalysis.h, TypeAnalysis.cpp, DependencyAnalysis.h,
ActionsAndRules.h, ActionsAndRules.cpp, ConfigureParser.h, ConfigureParser.cpp, DependencyAnalysis.cpp, FunctorClass.h
ItokCollection.h, SemiExpression.h, SemiExpression.cpp, tokenizer.h, tokenizer.cpp, taks.h, tasks.cpp, ThreadPool.h, ThreadPool.cpp
ParallelDependencyAnalysis.h , ParallelDependencyAnalysis.cpp

Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
#include"../ThreadPool/Cpp11-BlockingQueue.h"
#include"../TypeTable/TypeTable.h"
#include "../TypeAnalysis/TypeAnalysis.h"
#include "../DependencyAnalysis/DependencyAnalysis.h"
#include"../FunctorClass/FunctorClass.h"

using queue_ = BlockingQueue<TypeTable<TypeTableRecord>*>;
class pDepAnalysis
{
public:
	pDepAnalysis(){}
	~pDepAnalysis(){}
	void pass1(std::string filespecs);
	void doMerge(TypeTable<TypeTableRecord> &table);
	void pass2(std::string filespec, TypeTable<TypeTableRecord> &table);
	void doPrint();
private:
	size_t _numThreads;
	typeAnalysis typeAlys;
	depAnalysis dpalys;
static queue_ Typq;
static BlockingQueue<FunctorClass*> createdFunct;
};
#endif
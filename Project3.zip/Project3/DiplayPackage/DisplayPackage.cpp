///////////////////////////////////////////////////////////////////////
// DisplayPackage.cpp-Utiity package to display the dependency analysis//
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#include "DisplayPackage.h"
#include <iomanip>

///////////////////////////////////////////////////////////////
//Helper function to extract file name from filespecs

std::string displayPackage::shortenFileName(std::string filespec)
{
	std::string temp;
	char ch = '/';
	size_t i = 0;
	for (; ch != filespec[i]; i++);
	i++;
	for (; i < filespec.size(); i++)
		temp += filespec[i];
	return temp;
}

///////////////////////////////////////////////////////////////
//display function to display dependencies 

void displayPackage::display(BlockingQueue<std::unordered_map<std::string, std::vector<std::string>>*>& Dpq)
{
	showRecordHeader();
	while (Dpq.size() != 0)
	{
		using FileAssociations = std::unordered_map<std::string, std::vector<std::string>>;
		FileAssociations* FileassoRecord = Dpq.deQ();
		std::unordered_map<std::string, std::vector<std::string>>::iterator i = FileassoRecord->begin();
		if (FileassoRecord->size() != 0)
		{
			if (i->second.size() == 1)
			{
				std::cout << "\n  ";
				std::cout << std::setw(20) << shortenFileName(i->first);
				std::cout << std::setw(20) << " Does not depend on any file";
			}
			else
			{
				std::cout << "\n  ";
				std::cout << std::setw(20) << shortenFileName(i->first);
				for (size_t j = 0; j < i->second.size(); j++)
				{
					if (i->second[j] != " " && j == 0)
						std::cout << std::setw(20) << shortenFileName(i->second[j]);
					if (i->second[j] != " " && j != 0)
						std::cout << "  --" << shortenFileName(i->second[j]);
				}
			}
			std::cout << "\n \n";
			delete FileassoRecord; // deleting the File records created with new
		}
	}
}


///////////////////////////////////////////////////////////////
//This function helps in indentation


void displayPackage::showRecordHeader()
{
	std::cout << std::left << "\n  ";
	std::cout << std::setw(20) << "Current File";
	std::cout << std::setw(24) << "Dependency on Files";
	std::cout << "\n " << std::setw(24) << std::string(14, '-');
	std::cout << std::setw(20) << std::string(16, '-');
}

//Tes stub for display package

#ifdef TEST_DISPLAYPACKAGE_H
int main(int argc, char* argv[])
{
	std::cout << "\n  Testing DependencyAnalysis \n "
		<< std::string(30, '=') << std::endl;
	std::string fileSpec1 = "Praser.cpp";
	std::string fileSpec2 = "Praser.h";
	BlockingQueue<std::unordered_map<std::string, std::vector<std::string>>*> q;
	std::unordered_map<std::string, std::vector<std::string>> map;
	map[fileSpec1].push_back(fileSpec2);
	map[fileSpec2].push_back(fileSpec1);
	q.enQ(&map);
	displayPackage disp;
	disp.display(q);
}
#endif
#ifndef DISPLAYPACKAGE_H
#define DISPLAYPACKAGE_H
#include <string>
#include <iostream>
#include "../ThreadPool/Cpp11-BlockingQueue.h"
#include <unordered_map>
///////////////////////////////////////////////////////////////////////
// DisplayPackage.h-Utiity package to display the dependency analysis//
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
This is a Utility package which helps in displaying in the dependency analysis 

Public Interface:
=================
void display()       // Displays the dependency analysis result
Build Process:
==============
Required files
- DisplayPackage.h , DisplayPackage
Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/

class displayPackage
{
public:
	displayPackage(){}
	~displayPackage() {}
	void display(BlockingQueue<std::unordered_map<std::string, std::vector<std::string>>*>& Dpq);
private:
	void showRecordHeader();
	std::string shortenFileName(std::string filespec);
};

#endif
#ifndef TYPEANALYSIS_H
#define TYPEANALYSIS_H
///////////////////////////////////////////////////////////////////////
// TypeAnaysis.h - acts on specfied file for building partial type   //
// table                                                             //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
Buids the partial symbol table for the given filesppecs .It does this by building rules to detect type definitions: classes, structs, enums, 
typedefs, and aliases, and capture their fully qualified names and files where they are defined.

Public Interface:
=================
doTypAnalysis();                    // Build the partial symbol table for given files

Build Process:
==============
Required files
-  - Parser.h, Parser.cpp, TypeTable.h, TypeTable.cpp,TypeAnaysis.h ,TypeAnaysis.cpp
ActionsAndRules.h, ActionsAndRules.cpp, ConfigureParser.h, ConfigureParser.cpp,
ItokCollection.h, SemiExpression.h, SemiExpression.cpp, tokenizer.h, tokenizer.cpp

Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
#include "../Parser/ConfigureParser.h"
#include "../Parser/Parser.h"
#include"../TypeTable/TypeTable.h"
#include "../ThreadPool/Cpp11-BlockingQueue.h"

class typeAnalysis
{
public:
	void doTypAnalysis(std::string filespec, TypeTable<TypeTableRecord> *_ptable);
};


#endif
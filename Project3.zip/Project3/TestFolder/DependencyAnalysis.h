#ifndef DEPANALYSIS_H
#define DEPANALYSIS_H
///////////////////////////////////////////////////////////////////////
// DependencyAnaysis.h -acts on specfied files for finding dependency//
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
Finds, for single file in a specified file collection, all other files from the file collection on which they depend.
File A depends on file B, if and only if, it uses the name of any type or global function defined in file B.
It might do that by calling a function or method of a type or by inheriting the type.

Public Interface:
=================
doDepAnalysis();                    // Finds files on which the specified file depends
doprint()							//Prints the contents unordered map 

Build Process:
==============
Required files
-  - Parser.h, Parser.cpp, TypeTable.h, TypeTable.cpp,
ActionsAndRules.h, ActionsAndRules.cpp, ConfigureParser.h, ConfigureParser.cpp,
ItokCollection.h, SemiExpression.h, SemiExpression.cpp, tokenizer.h, tokenizer.cpp

Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
#include "../Parser/ConfigureParser.h"
#include "../Parser/Parser.h"
#include"../TypeTable/TypeTable.h"
#include"../ThreadPool/Cpp11-BlockingQueue.h"

using FileAssociations = std::unordered_map<std::string, std::vector<std::string>>;
using Depqueue_ = BlockingQueue<FileAssociations*>;
class depAnalysis
{
public:
	void doDepAnalysis(std::string filespec, TypeTable<TypeTableRecord> &_ptable);
	void doprint();
	void doEnqueue();
private:
	ConfigParseToConsole configure;
	static Depqueue_ Dpq;
};


#endif
///////////////////////////////////////////////////////////////////////
// TypeTable.h - unordered map which stores the types                //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
//Source : Jim Fawcett, CSE687 - Object Oriented Design,             // 
// Midterm Spring 2016                                               //
///////////////////////////////////////////////////////////////////////
#ifndef TESTTYPETABLE
#include"TypeTable.h"

using namespace Utilities;
using Utils = StringHelper;
/////////////////////////////////////////////////////////////////////


void main()
{
	Utils::Title("MT4Q1 - TypeTable");
	putline();
	TypeTable<TypeTableRecord> table;
	TypeTableRecord record;
	record.name() = "X";
	record.type() = "class";
	record.fileName() = "X.h";
	table.addRecord(record.name(),record);
	record.name() = "fun";
	record.type() = "method";
	record.fileName() = "X.h";
	table.addRecord(record.name(),record);
	showTypeTable(table);
	std::cout << "\n\n";
}
#endif*/
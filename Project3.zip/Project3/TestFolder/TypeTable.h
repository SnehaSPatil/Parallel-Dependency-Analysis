#ifndef TYPETABLE_H
#define TYPETABLE_H
///////////////////////////////////////////////////////////////////////
// TypeTable.h - unordered map which stores the types                //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
//Source : Jim Fawcett, CSE687 - Object Oriented Design,             // 
// Midterm Spring 2016                                               //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
Provides a Type table that stores the name , type , filename in it .It also provides useful methods to add , show, find record in the tabl

Public Interface:
=================
find()                                                //finds the value using key
addRecord()                                            //Inserts records into the table
Name() 							                 //returns name
FileName() 							                 //returns File name
Type() 							                 //returns Type
ShowRecord()                                   //Displays record

Build Process:
==============
Required files
- TypeTable.h,  TypeTable.cpp

Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <unordered_map>
#include "../Utilities/Utilities.h"
/*
*  The record class below could be simplified to a simple struct with
*  all public fields, assuming that our Table class doesn't need to
*  expose that to client code.
*
*  I chose to put most of the user interface into this record class,
*  so I do need the encapsulation used here.
*/
class TypeTableRecord
{
public:
	using Name = std::string;
	using Type = std::string;
	using FileName = std::string;
	void showRecord()
	{
		std::cout << "\n  ";
			std::cout << std::setw(16) << _whereDefined;
			std::cout << std::setw(20) << _name;
			std::cout << std::setw(20) << _type;
	}
	Name& name() { return _name; }
	Type& type() { return _type; }
	FileName& fileName() { return _whereDefined; }

private:
	Name _name;
	Type _type;
	FileName _whereDefined;
};

/////////////////////////////////////////////////////////////////////
// beginning of solution
//   - needs a few words about the record structure
//   - With a Record class that holds required information the
//     Table only needs to add records, store them, and provide access.
template<typename TableRecord>
class TypeTable
{
public:
	using iterator = typename std::unordered_map<std::string, TableRecord>::iterator;

	void addRecord(std::string key, const TableRecord& record)
	{
		_records.insert(std::make_pair(key,record));
	}
	void showRecord(TableRecord& record)
	{
		record.showRecord();
	}
	iterator find(std::string key)
	{
		return _records.find(key);
	}
	std::string fileName(iterator itr)
	{
		std::unordered_map<std::string, TypeTableRecord>::iterator i = itr;
		return i->second.fileName();
	}
	std::string Name(iterator itr)
	{
		std::unordered_map<std::string, TypeTableRecord>::iterator i = itr;
		return i->second.name();
	}
	std::string Type(iterator itr)
	{
		std::unordered_map<std::string, TypeTableRecord>::iterator i = itr;
		return i->second.type();
	}
	iterator begin() { return _records.begin(); }
	iterator end() { return _records.end(); }
private:
	std::unordered_map<std::string, TableRecord> _records; 
};

inline void showRecordHeader()
{
	std::cout << std::left << "\n  ";
	std::cout << std::setw(16) << "Filename";
	std::cout << std::setw(16) << "Name";
	std::cout << std::setw(16) << "Type" << "\n";
	std::cout << " " << std::setw(16) << std::string(14, '-');
	std::cout << std::setw(8) << std::string(6, '-');
	std::cout << std::setw(12) << std::string(10, '-');
}

template<typename TableRecord>
inline void showTypeTable(TypeTable<TableRecord>& table)
{
	showRecordHeader();
	std::unordered_map<std::string, TypeTableRecord>::iterator i = table.begin();
	while (i != table.end())
	{
		i->second.showRecord();
		i++;
	}
}

#endif*/
///////////////////////////////////////////////////////////////////////
// DependencyAnaysis.cpp -acts on specfied files for finding dependency//
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#include "DependencyAnalysis.h"
#include"../ActionsAndRules/ActionsAndRules.h"

Depqueue_ depAnalysis::Dpq;

///////////////////////////////////////////////////////////////
// Does the dependency analysis on a single file 

void depAnalysis::doDepAnalysis(std::string filespec, TypeTable<TypeTableRecord> &table)
{
	configure.setPassNo(2); // Configures parser for the second pass 
	configure.setPtablePonter(&table);
	configure.setFileName(filespec);
	Parser* pParser = configure.Build();
	try
	{
		if (pParser)
		{
			if (!configure.Attach(filespec))
			{
				std::cout << "\n  could not open file " << filespec << std::endl;
			}
		}
		else
		{
			std::cout << "\n\n  Parser not built\n\n";
			return;
		}
		// now that parser is built, use it
		while (pParser->next())
			pParser->parse();
		std::cout << "\n\n";
	}
	catch (std::exception& ex)
	{
		std::cout << "\n\n    " << ex.what() << "\n\n";
	}
	std::cout << "\n\n";
}

///////////////////////////////////////////////////////////////
// Prints the contents of the unordered map

void depAnalysis::doprint()
{
	while (Dpq.size() != 0)
	{
		using FileAssociations = std::unordered_map<std::string, std::vector<std::string>>;
		FileAssociations* FileassoRecord = Dpq.deQ();
		std::unordered_map<std::string, std::vector<std::string>>::iterator i = FileassoRecord->begin();
		if (FileassoRecord->size() != 0)
		{
			if (i->second.size() == 1)
			std::cout << "\n File: " << i->first << " Does not depend on any file";
			else
			{
				std::cout << "\n File: " << i->first << " depends on the following files:";
				for (size_t j = 0; j < i->second.size(); j++)
				{
					if(i->second[j] != " ")
					std::cout << "\nFile: " << i->second[j];
				}
			}
			std::cout << "\n \n";
			delete FileassoRecord; // deleting the File records created with new
		}
	}
}

///////////////////////////////////////////////////////////////
// Enqueues to the results queue for dependency analysis

void depAnalysis::doEnqueue()
{
	FileAssociations *FileassoRecord = configure.getFileAssociations();
	Dpq.enQ(FileassoRecord);
}

//Test Stub for Deendency Analysis

#ifdef TEST_DEPENDENCYANALYSIS
#include "../TypeAnalysis/TypeAnalysis.h"

int main(int argc, char* argv[])
{
	std::cout << "\n  Testing DependencyAnalysis \n "
		<< std::string(30, '=') << std::endl;
	std::string fileSpec1 = "../Parser/Praser.cpp";
	std::string fileSpec2 = "../Parser/Praser.h";
	typeAnalysis typeAlys;
	TypeTable<TypeTableRecord> *ptble1 , *ptble2;
	typeAlys.doTypAnalysis(fileSpec1, ptble1);
	typeAlys.doTypAnalysis(fileSpec2, ptble2);
	std::unordered_map<std::string, TypeTableRecord>::iterator i = ptble2->begin();
	while (i != ptble2->end())
	{
		ptble1->addRecord(i->first, i->second);
		i++;
	}
	depAnalysis depAl;
	depAl.doDepAnalysis(fileSpec1, *ptble1);
	depAl.doprint();
}
#endif
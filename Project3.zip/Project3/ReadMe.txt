ReadMe.txt

This deendency analyseer handles only basic cases of typedefs and usings . 
It handles class , struct , enums , functions . It does not handle the namespaces but here is how it could have been done:
The type analysis would need to capture the namespaces and correcponding files in a vector alongwith type and 
While doing the dependency analysis while tokenising we will create our usings table. If while finding the key in the merged
symbol table we notice that the size of vector containing file is more than 1 than we compare the namespaces stored in the usings
table with the namespace in symbol table. This gives us the correct file name.

The display package has been created to facilitate the display of files an there dependencies on adjacent lines. 
However it was not used in the demonstaration since there coud be two files with the same name in different folders. 
This would require the display of full path instead of just fiename and the display of full file specs on the adjacent lines is illegible.
The display call to this function if uncommented in parallelDependencyAnalysis shows the files dependencies on adjacent lines.
///////////////////////////////////////////////////////////////////////
// ThreadPool.h -multiple child thread processes enqueued work items //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
//Source :Jim Fawcett,QueuedWorkItems package                        //
///////////////////////////////////////////////////////////////////////

#include "ThreadPool.h"

//----< wait for child thread to terminate >---------------------------

void ProcessWorkItem::wait()
{
	for (size_t i = 0; i < NoParallelThreads; i++)
	{
		if(_pThread[i] ->joinable())
		_pThread[i]->join();
	}
}
//----< enqueue work item >--------------------------------------------

void ProcessWorkItem::doWork(WorkItem* pWi)
{
	_workItemQueue.enQ(pWi);
}

//----< start multiple child thread that dequeus work items >-------------------

void ProcessWorkItem::start()
{
	std::function<void()> threadProc =
		[&]() {
		while (true)
		{
			WorkItem* pWi = _workItemQueue.deQ();
			if (pWi == nullptr)
			{
				std::cout << "\n  shutting down work item processing";
				return;
			}
			(*pWi)();
		}
	};
	for (size_t i = 0; i < NoParallelThreads; i++)
	{
		_pThread[i] = new std::thread(threadProc);
	}
}
//----< clean up heap >------------------------------------------------
ProcessWorkItem::~ProcessWorkItem()
{
	for (size_t i = 0; i < NoParallelThreads; i++)
	{
		delete _pThread[i];
	}
}



#ifdef TEST_THREADPOOL


//----< demonstrate ProcessWorkItem class >----------------------------



using Util = Utilities::StringHelper;
using WorkResult = std::string;

int main()
{
	Util::Title("Enqueued Work Items");

	std::cout << "\n  main thread id = " << std::this_thread::get_id();

	std::cout << "\n  Testing DependencyAnalysis \n "
		<< std::string(30, '=') << std::endl;
	std::string fileSpec1 = "../Parser/Praser.cpp";
	std::string fileSpec2 = "../Parser/Praser.h";
	BlockingQueue<TypeTable<TypeTableRecord>*> q;
	ProcessWorkItem processor;
	processor.setNumThreads(5);
	processor.start();

	// define 1st work item

	FunctorClass depA1(fileSpec2, 1, &q);
	WorkItem &wi1 = depA1;
	processor.doWork(&wi1);


	FunctorClass depA2(fileSpec2, 1, &q);
	WorkItem &wi2 = depA2;
	processor.doWork(&wi2);


	processor.doWork(nullptr);
	processor.doWork(nullptr);
	processor.doWork(nullptr);
	processor.doWork(nullptr);
	processor.doWork(nullptr);
	// wait for child thread to complete

	processor.wait();
	std::cout << "\n\n";
	return 0;
}

#endif // TEST_THREADPOOL
///////////////////////////////////////////////////////////////////////
// ActionsAndRules.cpp - read words from a std::stream                 //
// ver  1.0                                                          //
// Language:    C++, Visual Studio 2015                              //
// Application:  Parallel Dependency Analysis,                       //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
// Actions and Rules testStub
#ifdef TEST_ACTIONSANDRULES

#include <fstream>
#include <iostream>
#include <sstream>
#include "ActionsAndRules.h"
#include "../Tokenizer/Tokenizer.h"
#include "../SemiExp/SemiExp.h"
#include "../ScopeStack/ScopeStack.h"
#include "../TypeTable/TypeTable.h"

using namespace Scanner;
int main(int argc, char* argv[])
{
  std::cout << "\n  Testing ActionsAndRules class\n "
            << std::string(30,'=') << std::endl;
  try
  {
    Toker toker;
	std::string fileSpec = "../Parser/Praser.cpp";

	std::fstream in(fileSpec);
	if (!in.good())
	{
		std::cout << "\n  can't open file " << fileSpec << "\n\n";
		return 1;
	}
	else
	{
		std::cout << "\n  processing file \"" << fileSpec << "\"\n";
	}
	toker.attach(&in);
    SemiExp se(&toker);
    Parser parser(&se);
	Repository* pRepo = new Repository(&toker);
	BeginningOfScope* pBeginningOfScope = new BeginningOfScope();
	HandlePush *pHandlePush = new HandlePush(pRepo);
	pBeginningOfScope->addAction(pHandlePush);
	parser.addRule(pBeginningOfScope);
	TypeTable<TypeTableRecord> *_ptable;
	pRepo->settypeTable(_ptable);
	pRepo->setcurrentFile("Praser.cpp");
	while(se.get())
      parser.parse();
	showTypeTable(*_ptable);
    std::cout << "\n\n";
  }
  catch(std::exception& ex)
  {
    std::cout << "\n\n  " << ex.what() << "\n\n";
  }
}
#endif

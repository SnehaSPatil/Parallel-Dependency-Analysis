#ifndef ACTIONSANDRULES_H
#define ACTIONSANDRULES_H
///////////////////////////////////////////////////////////////////////
// ActionsAndRules.h - acts on specfied rules for parsing tokens     //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
  Module Operations: 
  ==================
  The BegginingOfscopes rule checks for the scopes , typedefandusings rule detects typedef and usings . These rules along with their actions fill 
  the partial type tabe. The Tokenize rule and its action find the dependency analysis by looking up into the merge table.
  Public Interface:
  =================
  Toker t(someFile);              // create tokenizer instance
  lineCount();                    // gives the current line count
  symbolTable()                    // gives the instance of symbol table
  fileAssociations()             // gives the file Association
  currentFile();                  //gives the current file name
  setcurrentFile()                // ets the current file name
  
  Build Process:
  ==============
  Required files
    -  - Parser.h, Parser.cpp, TypeTable.h, TypeTable.cpp,ConfigureParser.h
      ActionsAndRules.h, ActionsAndRules.cpp, ConfigureParser.cpp,
      ItokCollection.h, SemiExpression.h, SemiExpression.cpp, tokenizer.h, tokenizer.cpp
  Build commands 
    - devenv Project3.sln /rebuild debug
    
  Maintenance History:
  ====================
  ver 1.0 : 12 Mar 16
 */
//
#include <queue>
#include <string>
#include <sstream>
#include <unordered_map>
#include "../Parser/Parser.h"
#include <memory>
#include "../SemiExp/itokcollection.h"
#include "../Tokenizer/Tokenizer.h"
#include "../SemiExp/SemiExp.h"
#include"../TypeTable/TypeTable.h"

///////////////////////////////////////////////////////////////
// Repository is application specific 

class Repository  // application specific
{
	using FileSpec = std::string;
	using FileAssociations = std::unordered_map<FileSpec, std::vector<FileSpec>>;
	FileSpec _currentFile;
	TypeTable<TypeTableRecord> *_table;
	Scanner::Toker* p_Toker;
	FileAssociations* _fileAssociations = new FileAssociations;

public:
	Repository(Scanner::Toker* pToker)
	{
		p_Toker = pToker;
	}

	TypeTable<TypeTableRecord>* symbolTable()
	{
		return _table;
	}
	void settypeTable(TypeTable<TypeTableRecord> *table)
	{
		_table = table;
	}
	Scanner::Toker* Toker()
	{
		return p_Toker;
	}
	size_t lineCount()
	{
		return (size_t)(p_Toker->currentLineCount());
	}
	void setcurrentFile(FileSpec currentFile)
	{
		_currentFile = currentFile;
		setFileAssociation(currentFile, " ");
	}

	FileSpec& currentFile() { return _currentFile; }

	void setFileAssociation(const FileSpec& thisFile, const FileSpec& includeFile)
	{
		(*_fileAssociations)[thisFile].push_back(includeFile);
	}
	FileAssociations* fileAssociations()
	{
		return _fileAssociations;
	}
};

///////////////////////////////////////////////////////////////
// rule to detect beginning of anonymous scope

class BeginningOfScope : public IRule
{
public:
  bool doTest(ITokCollection*& pTc)
  {

    if(pTc->find("{") < pTc->length())
    {
	    doActions(pTc);
      return true;
    }
    return true;
  }
};

///////////////////////////////////////////////////////////////
// rule to detect typedefs and Usings of anonymous scope

class TypedefUsingdetection : public IRule
{
public:
	bool doTest(ITokCollection*& pTc)
	{

		if (pTc->find("typedef") < pTc->length() || pTc->find("using") < pTc->length())
		{
			doActions(pTc);
			return true;
		}
		return true;
	}
};

///////////////////////////////////////////////////////////////
// action to handle typedefs and usings

class Handletypedefsandusings  : public IAction
{
	Repository* p_Repos;
	std::string controlsignalName_;
public:
	Handletypedefsandusings(Repository* pRepos)
	{
		p_Repos = pRepos;
	}
	void doAction(ITokCollection*& pTc)
	{
		ITokCollection& tc = *pTc;
		//Handles only the basic typedefs
		if (pTc->find("typedef") < pTc->length() && pTc->find(";") < pTc->length())
		{
			TypeTableRecord record;
			record.name() = (*pTc)[pTc->find(";") - 1];
			if (record.name().size() == 1 && ispunct(record.name()[0]))
				return;
			record.type() = "typedef";
			record.fileName() = p_Repos->currentFile();
			p_Repos->symbolTable()->addRecord(record.name(), record);
		}
		//Handles only the basic usings
		else if(pTc->find("using") < pTc->length() && pTc->find("=") < pTc->length())
		{
			TypeTableRecord record;
			record.name() = (*pTc)[pTc->find("=") - 1];
			record.type() = "using";
			record.fileName() = p_Repos->currentFile();
			p_Repos->symbolTable()->addRecord(record.name(), record);
		}
	}
};

///////////////////////////////////////////////////////////////
// action to handle the defination at beginning of scope. It detcts class, struct and enums

class HandleDataTypeDetection : public IAction
{
	Repository* p_Repos;
	std::string controlsignalName_;
public:
	HandleDataTypeDetection(Repository* pRepos)
	{
		p_Repos = pRepos;
	}
	bool isDataStruct(ITokCollection*& pTc)
	{
		const static std::string keys2[]
			= { "class", "struct","enum"};
		for (int i = 0; i<3; ++i)
			if (pTc->find(keys2[i]) < pTc->length())
			{
				controlsignalName_ = keys2[i];
				return true;
			}
		return false;
	}
	void doAction(ITokCollection*& pTc)
	{
		ITokCollection& tc = *pTc;
		if (tc[tc.length() - 1] == "{"  && isDataStruct(pTc))
		{
			TypeTableRecord record;
			if ((*pTc)[pTc->find(controlsignalName_) + 1] == "{")
				return;
			record.name() = (*pTc)[pTc->find(controlsignalName_) + 1];
			record.type() = controlsignalName_;
			record.fileName() = p_Repos->currentFile();
			p_Repos->symbolTable()->addRecord(record.name(),record);
		}
	}
};


///////////////////////////////////////////////////////////////
// action to handle all types of Functions either global or member functions

class HandleFunctionDetection : public IAction
{
  Repository* p_Repos;
  std::string controlsignalName_;
public:
	HandleFunctionDetection(Repository* pRepos)
  {
    p_Repos = pRepos;
  }
  bool isSpecialKeyWord(const std::string& tok)
  {
	  const static std::string keys[]
		  = { "for", "while", "switch", "if", "catch" };
	  for (int i = 0; i<5; ++i)
		  if (tok == keys[i])
		  {
			  controlsignalName_ = keys[i];
			  return true;
		  }
	  return false;
  }
  void doAction(ITokCollection*& pTc)
  {
   	  ITokCollection& tc = *pTc;
	  size_t len = tc.find("(");
	   	  if (tc[tc.length() - 1] == "{" && len < tc.length() && !isSpecialKeyWord(tc[len - 1]))
		  {
			  TypeTableRecord record;
			  record.name() = (*pTc)[pTc->find("(") - 1];
			  if (record.name() == "main" || record.name().size() == 1 && ispunct(record.name()[0]))
				  return;
			  record.type() = "function";
			  record.fileName() = p_Repos->currentFile();
			  p_Repos->symbolTable()->addRecord(record.name(),record);
		  }
  }
};

///////////////////////////////////////////////////////////////
// rule to tokenize every single expression

class Tokenize : public IRule
{
public:
	bool doTest(ITokCollection*& pTc)
	{
			doActions(pTc);
		return true;
	}
};

///////////////////////////////////////////////////////////////
// action to save include file

class SaveAssociation : public IAction
{
	Repository* p_Repos;
public:
	
	SaveAssociation(Repository* pRepos) : p_Repos(pRepos) {}
	void doAction(ITokCollection*& pTc)
	{
		for (size_t i = 0; i < pTc->length(); i++)
		{
			std::string token = (*pTc)[i];
			auto recordItr = p_Repos->symbolTable()->find(token);
			if (recordItr != p_Repos->symbolTable()->end())
			{				
					if (p_Repos->currentFile() != p_Repos->symbolTable()->fileName(recordItr))
					{
						if (p_Repos->fileAssociations()->size() != 0)
						{
							std::unordered_map<std::string, std::vector<std::string>>::iterator itr = p_Repos->fileAssociations()->begin();
							size_t  same = 0;
							for (size_t k = 0; k < itr->second.size(); k++)
							{
								if (itr->second[k] == p_Repos->symbolTable()->fileName(recordItr))
									same = 1;
							}
							if (same == 0)
								p_Repos->setFileAssociation(p_Repos->currentFile(), p_Repos->symbolTable()->fileName(recordItr));
						}
						else
							p_Repos->setFileAssociation(p_Repos->currentFile(), p_Repos->symbolTable()->fileName(recordItr));
					}
				
			}
		}
	}
};

#endif

#ifndef FUNCTORCLASS_H
#define FUNCTORCLASS_H
///////////////////////////////////////////////////////////////////////
// FunctorClass.h -Defines the application specific functor for type //
// and dependency analysis                                           //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
This module is an application specific module which defines the functor which can do type anlysis 
and dependency analysis depending on the arguments passed to the constructor

Public Interface:
=================
DeptypFunctorClass(std::string filespecs, TypeTable<TypeTableRecord> & table, size_t passNo) //Creates the functor for type analysis
DeptypFunctorClass(std::string filespecs, size_t passNo, queue_* _q) //Creates the functor for dependency analysis
void operator() () 							//operator paren function which defines the funcctionality of functor

Build Process:
==============
Required files
-  - Parser.h, Parser.cpp, TypeTable.h, TypeTable.cpp, TypeAnalysis.h, TypeAnalysis.cpp, DependenccyAnalysis.h, 
ActionsAndRules.h, ActionsAndRules.cpp, ConfigureParser.h, ConfigureParser.cpp, DependenccyAnalysis.cpp
ItokCollection.h, SemiExpression.h, SemiExpression.cpp, tokenizer.h, tokenizer.cpp, FunctorClass.h,FunctorClass.cpp

Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
#include"../TypeTable/TypeTable.h"
#include"../DependencyAnalysis/DependencyAnalysis.h"
#include"../TypeAnalysis/TypeAnalysis.h"
using queue_ = BlockingQueue<TypeTable<TypeTableRecord>*>;
class FunctorClass
{
public:
	FunctorClass(std::string filespecs, TypeTable<TypeTableRecord> & table, size_t passNo) : _filespecs(filespecs), _tabel(table), _passNo(passNo) {}
	FunctorClass(std::string filespecs, size_t passNo, queue_* _q) : _filespecs(filespecs), _passNo(passNo),q(_q) {}
	void operator() () {
		if (_passNo == 2) // Does dependency analysis
		{
			depAlys.doDepAnalysis(_filespecs, _tabel);
			std::cout << "\n  working on thread " << std::this_thread::get_id();
			depAlys.doEnqueue();
		}
		else if (_passNo == 1)//  Does type analysis
		{
			TypeTable<TypeTableRecord>* pTable = new TypeTable<TypeTableRecord>;
			typeAlys.doTypAnalysis(_filespecs, pTable);
			q->enQ(pTable);
			//showTypeTable(*pTable);
			std::cout << "\n  working on thread " << std::this_thread::get_id();
		}
		else//  default void operation
		{ }
	}
private:
	std::string _filespecs;
	depAnalysis depAlys;
	typeAnalysis typeAlys;
	TypeTable<TypeTableRecord> _tabel;
	size_t _passNo;
	queue_* q;
};

#endif
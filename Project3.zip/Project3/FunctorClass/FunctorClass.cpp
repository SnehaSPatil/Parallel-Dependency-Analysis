///////////////////////////////////////////////////////////////////////
// FunctorClass.h -Defines the application specific functor for type //
// and dependency analysis                                           //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

//Test Stub for FunctorClass

#ifdef TEST_FUNCTORCLASS
#include "FunctorClass.h"
#include "../TypeAnalysis/TypeAnalysis.h"
#include "../Tasks/Task.h"

int main(int argc, char* argv[])
{
	std::cout << "\n  Testing DependencyAnalysis \n "
		<< std::string(30, '=') << std::endl;
	std::string fileSpec1 = "../Parser/Praser.cpp";
	std::string fileSpec2 = "../Parser/Praser.h";
	BlockingQueue<TypeTable<TypeTableRecord>*> q;

	FunctorClass depA1(fileSpec2, 1, &q);
	WorkItem &wi1 = depA1;
	task task1(&wi1);

	FunctorClass depA2(fileSpec2, 1, &q);
	WorkItem &wi2 = depA2;
	task task2(&wi2);
	task2.signalStop();
	task2.wait();
	task2.reset();
	typeAnalysis typeAlys;
	TypeTable<TypeTableRecord> SymboleTable;
	typeAlys.doMerge(SymboleTable, q);

	FunctorClass depA3(fileSpec2, 1, &q);
	WorkItem &wi3 = depA3;
	task task3(&wi3);
	task3.signalStop();
	task3.wait();
	task3.reset();
}
#endif
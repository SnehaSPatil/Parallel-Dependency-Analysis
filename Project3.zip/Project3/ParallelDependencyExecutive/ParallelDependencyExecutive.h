#ifndef PARALLELDEPENDENCYEXECUTIVE_H
#define PARALLELDEPENDENCYEXECUTIVE_H
///////////////////////////////////////////////////////////////////////
// ParallelDependencyExecutive.h -finds all the compilation dependencies//
// between files in a file collection                                //
// and dependency analysis                                           //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////
/*
Module Operations:
==================
finds all the compilation dependencies between files in a file collection. 
Each of the files in the collection are found in a directory tree rooted at a specified path 
and whose names match one or more specified patterns.

Public Interface:
=================
runParallelDepExecutive() // finds the files in specified pattern and calculates the parallel dependecies

Build Process:
==============
Required files
-  - Parser.h, Parser.cpp, TypeTable.h, TypeTable.cpp, TypeAnalysis.h, TypeAnalysis.cpp, DependencyAnalysis.h,FileMgr.h, FileMgr.cpp
ActionsAndRules.h, ActionsAndRules.cpp, ConfigureParser.h, ConfigureParser.cpp, DependencyAnalysis.cpp, FunctorClass.h
ItokCollection.h, SemiExpression.h, SemiExpression.cpp, tokenizer.h, tokenizer.cpp, taks.h, tasks.cpp, ThreadPool.h, ThreadPool.cpp
ParallelDependencyAnalysis.h , ParallelDependencyAnalysis.cpp,ParallelDependencyExecutive.h, ParallelDependencyExecutive.cpp

Build commands
- devenv Project3.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 12 Mar 16
*/
#include "../FileMgr/FileMgr.h"
#include <iostream>
#include "../ParallelDependencyAnalysis/ParallelDependencyAnalysis.h"
#include"../TypeTable/TypeTable.h"
#include"../Tasks/Task.h"


using namespace FileManager;
//when a file is found execute function is called 
struct FileHandler : IFileEventHandler
{
	//Returns the reference to access type table
	TypeTable<TypeTableRecord>& getTypeTable()
	{
		return Table;
	}
	void setTypeTable(TypeTable<TypeTableRecord>& table)
	{
		Table = table;
	}
	// returns instance of prallel dependancy analysis
	pDepAnalysis* pDepAnalysisPointer()
	{
		return PDep;
	}
	//when a file is found execute function is called
	void execute(const std::string& fileSpec)
	{
		if (passNo == 1)
			PDep->pass1(fileSpec);
		else if (passNo == 2)
			PDep->pass2(fileSpec, Table);
	}
	//sets the pass number
	void setPassNo(size_t _passNo)
	{
		passNo = _passNo;
	}
private:
	pDepAnalysis *PDep;
	size_t passNo = 1;
	TypeTable<TypeTableRecord> Table;
};

class ParallelDepExec
{
public:
	ParallelDepExec() {}
	void runParallelDepExecutive(int argc, char* argv[]);
};
#endif
///////////////////////////////////////////////////////////////////////
// ParallelDepExecutive.cpp -finds all the compilation dependencies  //
// between files in a file collection                                //
// ver 1.0                                                           //
// Language:    C++, Visual Studio 2015                              //
// Application: Parallel Dependency Analysis,                        //
//                                CSE687 - Object Oriented Design    //
// Author:      Seha Patil, Syracuse University,                     //
//              spatil01@syr.edu                                     //
///////////////////////////////////////////////////////////////////////

#define TEST_PARALLELDEPEXEC
#ifdef TEST_PARALLELDEPEXEC

#include "../FileMgr/FileMgr.h"
#include <iostream>
#include "../ParallelDependencyAnalysis/ParallelDependencyAnalysis.h"
#include"../TypeTable/TypeTable.h"
#include"../Tasks/Task.h"
#include "ParallelDependencyExecutive.h"

//Finds the files and does the dependency analysis using other packages
void ParallelDepExec::runParallelDepExecutive(int argc, char* argv[])
{
	std::string path = FileSystem::Path::getFullFileSpec(argv[1]);
	IFileMgr* pFmgr = FileMgrFactory::create(path);
	FileHandler fh;
	pDepAnalysis *PDep = fh.pDepAnalysisPointer();
	pFmgr->regForFiles(&fh);
	//adding patterns
	for (int i = 2; i < argc; ++i)
	{
		pFmgr->addPattern(argv[i]);
	}
	//searching for files
	pFmgr->search();
	PDep->pass1("End of Files");
	TypeTable<TypeTableRecord> Table = fh.getTypeTable();
	std::cout << "\n \n\n*****************Displaying Merged Symbol Table ***********************************\n";
	PDep->doMerge(Table);
	fh.setTypeTable(Table);
	fh.setPassNo(2);
	//searching for files
	pFmgr->search();
	PDep->pass2("End of Files", Table);
	std::cout << "\n \n\n********************Displaying dependency analysis result**************************** \n";
	PDep->doPrint();
}

//Executive main unit test suite
int main(int argc, char* argv[])
{
	if (argc < 2)
	{
		std::cout<< "\n  please enter path to process on command line\n\n";
		return 1;
	}
	std::cout << "\n  Testing Parallel Dependency Analysis";
	std::cout << "\n =================";
	std::cout << "\nThe requirements 1 to 10 have been handled. Below display shows Merged typetable and dependency analysis result\n";
	std::cout << "\n ===================================================================================================================";
	try
	{
		ParallelDepExec pdepEx;
		pdepEx.runParallelDepExecutive( argc,  argv);
	}
	catch (std::exception& ex)
	{
		std::cout << "\n\n    " << ex.what() << "\n\n";
	}
	std::cout << "\n\n";
}
#endif